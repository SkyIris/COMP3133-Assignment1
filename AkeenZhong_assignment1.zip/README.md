Akeen Zhong
101462287
COMP 3133 Full Stack Assignment 1
GraphQL RestAPI

Dependencies: express, graphql, express-graphql, dotenv, mongoose