module.exports = {
    User: require("./User"),
    Card: require("./Card")
}